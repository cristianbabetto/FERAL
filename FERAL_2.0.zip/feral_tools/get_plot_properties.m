function get_plot_properties(PlotProp)

% convert to cell the input
if ~iscell(PLotProp)
  PlotProp = {PlotProp};
end

if 
  
  
for row_idx = 1 : size(PlotProp, 1) % each row is a plot


end % function