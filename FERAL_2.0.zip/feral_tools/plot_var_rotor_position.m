%% TEMPLATE for plotting the sim_var_rotor_position results

%% Flux linkages
% waveform
plot

% harmonics

%% Airgap flux density
% waveform


% harmonics


%% Torque waveforms
% waveform

% harmonics

%% Other plots ...