function isOctave = isOctave()
% ISOCTAVE() returns true if this code is being executed by Octave.
% Returns false if this code is being executed by MATLAB, or any other MATLAB
% variant.
%
%    isOctave = ISOCTAVE()

% Copyright (c) 2010, Kurt von Laven
% All rights reserved.
persistent octaveVersionIsBuiltIn;
if (isempty(octaveVersionIsBuiltIn))
  octaveVersionIsBuiltIn = (exist('OCTAVE_VERSION', 'builtin') == 5);
  % exist returns 5 to indicate a built-in function.
end
isOctave = octaveVersionIsBuiltIn;
% If OCTAVE_VERSION is a built-in function, then we must be in Octave.
% Since the result cannot change between function calls, it is cached in a
% persistent variable. isOctave cannot be a persistent variable, because it
% is the return value of the function, so instead the persistent result must
% be cached in a separate variable.

end
